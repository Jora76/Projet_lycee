# -*- coding: Utf8 -*-
from tkinter import *
from random import randrange
from math import*

def damier():   #Création du damier
   x=0
   for i in range(10):
      y=0
      for j in range(10):
         can1.create_rectangle(x,y,x+50,y+50, fill='')
         y=y+100
      x=x+100

   x=50
   for i in range(10):
      y=50
      for j in range(10):
         can1.create_rectangle(x,y,x+50,y+50, fill='')
         y=y+100
      x=x+100

def calc(event): #Déplacement du personnage
   global position,a,b,c,d,item
   x=event.x   #Détecte position en x et y du clic
   y=event.y
   d=str(int((c-25)//50)-1)
   if compt%2==0:
      item=item1
   else:
      item=item2
   if sqrt(((x-position[compt%2][0])**2)+((y-position[compt%2][1])**2))>c: #limite des déplacements
      print("tu peux pas")
   else:
      x=x//50
      x=x*50+25
      y=y//50
      y=y*50+25
      c=c-sqrt(((x-position[compt%2][0])**2)+((y-position[compt%2][1])**2))
      can1.coords(item,x,y)
      position[compt%2][0]=x
      position[compt%2][1]=y
      var_Label.configure(text="Points de déplacement : " + d)

def tour():
   global compt,c
   compt=compt+1
   c=175
   d=3
   var_Label.configure(text="Points de déplacement : 3 ")


#def hitbox():


#def atak():

#--------Programme principal--------#


#Widget principal (maître)
fen1= Tk()
fen1.title("Jovato")


#Widgets (esclaves)
can1= Canvas(fen1, bg="white",height=600, width=600)
can1.pack(side=TOP)

carte= PhotoImage(file="map-finit.gif")
photo= can1.create_image(500,500,image=carte)

damier()

pers= PhotoImage(file="Perso_1_3.gif") #Personnage
item1= can1.create_image(225,425, image= pers)
pers2= PhotoImage(file="Perso_2_3.gif")
item2= can1.create_image(225,75,image=pers2)

compt=0
position=[[225,445],[225,75]]
print(position[compt%2][1])

var_Label= Label(fen1, text="points de deplacement : 3")
var_Label.pack()

a=225
b=445
c=175
can1.bind("<Button-1>",calc)

bou1= Button(fen1, text="Quitter", width=10, height=5, command=fen1.quit) #Bouton quitter
bou1.pack(side=RIGHT, padx=20, pady=20)

bou2= Button(fen1, text="Passer son tour", width=10, height=5,command=tour)
bou2.pack(side=BOTTOM, padx=20, pady=20)

fen1.mainloop()
fen1.destroy()